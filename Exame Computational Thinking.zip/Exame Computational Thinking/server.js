const express = require('express');
const app = express();
const port = 3000;

// Middleware para parsing de JSON
app.use(express.json());

// Array para armazenar as tarefas temporariamente
let tasks = [];

// Função para gerar IDs únicos
const generateId = () => {
  return tasks.length > 0 ? tasks[tasks.length - 1].id + 1 : 1;
};

// Rota POST /tasks: Adiciona uma nova tarefa
app.post('/tasks', (req, res) => {
  const { title, description } = req.body;
  if (!title || !description) {
    return res.status(400).json({ error: 'Título e descrição são obrigatórios.' });
  }
  const newTask = { id: generateId(), title, description };
  tasks.push(newTask);
  res.status(201).json(newTask);
});

// Rota GET /tasks: Retorna todas as tarefas
app.get('/tasks', (req, res) => {
  res.json(tasks);
});

// Inicia o servidor
app.listen(port, () => {
  console.log(`Servidor rodando em http://localhost:${port}`);
});